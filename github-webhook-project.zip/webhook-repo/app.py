
from flask import Flask, request, jsonify, render_template
from flask_pymongo import PyMongo
from datetime import datetime, timedelta
from bson.json_util import dumps
import os

app = Flask(__name__)
app.config["MONGO_URI"] = os.getenv("MONGO_URI", "mongodb://localhost:27017/webhookDB")
mongo = PyMongo(app)

events_collection = mongo.db.events

@app.route('/webhook', methods=['POST'])
def webhook():
    data = request.json
    if not data:
        return jsonify({"error": "No data received"}), 400

    record = {
        "event_type": data.get('event_type'),
        "author": data.get('author'),
        "from_branch": data.get('from_branch'),
        "to_branch": data.get('to_branch'),
        "timestamp": datetime.utcnow()
    }
    events_collection.insert_one(record)
    return jsonify({"message": "Event stored"}), 200

@app.route('/events', methods=['GET'])
def get_events():
    now = datetime.utcnow()
    cutoff = now - timedelta(minutes=30)
    cursor = events_collection.find({"timestamp": {"$gte": cutoff}}).sort("timestamp", -1)
    events = []
    for e in cursor:
        ts = e["timestamp"].strftime('%d %b %Y - %I:%M %p UTC')
        if e["event_type"] == 'push':
            msg = f"{e['author']} pushed to {e['to_branch']} on {ts}"
        elif e["event_type"] == 'pull_request':
            msg = f"{e['author']} submitted a pull request from {e['from_branch']} to {e['to_branch']} on {ts}"
        elif e["event_type"] == 'merge':
            msg = f"{e['author']} merged branch {e['from_branch']} to {e['to_branch']} on {ts}"
        else:
            msg = f"{e['author']} performed {e['event_type']} on {ts}"
        events.append(msg)
    return jsonify(events), 200

@app.route('/')
def index():
    return render_template("index.html")

if __name__ == '__main__':
    app.run(debug=True, port=5000)
